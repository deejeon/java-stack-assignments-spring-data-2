package com.danieljeon.productsandcategories.controllers;

public class CategoriesController {

}
